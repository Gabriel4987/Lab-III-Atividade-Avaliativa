package AtividadeAvaliativa;

public class Usuario {
    
    //Atributos
    private int id;
    private String nome;
    private String email;
    private String senha;

    //Construtor padrão
    public Usuario() {
    }

    //Construtor sobrecarregado
    public Usuario(int id, String nome, String email, String senha) {
        this.id = id;
        this.nome = nome;
        this.email = email;
        this.senha = senha;
    }

    //Retorno do id
    public int getId() {
        return id;
    }

    //Modificar o id
    public void setId(int id) {
        this.id = id;
    }

    //Retorno do nome
    public String getNome() {
        return nome;
    }

    //Modificar o nome
    public void setNome(String nome) {
        this.nome = nome;
    }

    //Retorno do email
    public String getEmail() {
        return email;
    }

    //Modificar o email
    public void setEmail(String email) {
        this.email = email;
    }

    //Retorno da senha
    public String getSenha() {
        return senha;
    }

    //Modificar a senha
    public void setSenha(String senha) {
        this.senha = senha;
    }

    //Metodo toString
    @Override
    public String toString() {
        return "Usuario{" + "id=" + id + ", nome=" + nome + ", email=" + email + ", senha=" + senha + '}';
    }
}