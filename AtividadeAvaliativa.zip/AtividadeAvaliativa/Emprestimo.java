package AtividadeAvaliativa;

import java.time.LocalDate;

public class Emprestimo {
    
    //Atributos
    private int id;
    private int idUsuario;
    private int idLivro;
    private LocalDate dataEmprestimo;
    private LocalDate dataDevolucao;
    private boolean devolvido;

    //Construtor padrão
    public Emprestimo() {
    }

    //Construtor sobrecarregado
    public Emprestimo(int id, int idUsuario, int idLivro, LocalDate dataEmprestimo, LocalDate dataDevolucao, boolean devolvido) {
        this.id = id;
        this.idUsuario = idUsuario;
        this.idLivro = idLivro;
        this.dataEmprestimo = dataEmprestimo;
        this.dataDevolucao = dataDevolucao;
        this.devolvido = devolvido;
    }

    //Retorno do id
    public int getId() {
        return id;
    }

    //Modificar o id
    public void setId(int id) {
        this.id = id;
    }

    //Retorno do id do usuario
    public int getIdUsuario() {
        return idUsuario;
    }

    //Modificar o id do usuario
    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    //Retorno do id do livro
    public int getIdLivro() {
        return idLivro;
    }

    //Modificar o id do livro
    public void setIdLivro(int idLivro) {
        this.idLivro = idLivro;
    }

    //Retorno da data de emprestimo
    public LocalDate getDataEmprestimo() {
        return dataEmprestimo;
    }

    //Modificar a data de emprestimo
    public void setDataEmprestimo(LocalDate dataEmprestimo) {
        this.dataEmprestimo = dataEmprestimo;
    }

    //Retorno da data de devolucao
    public LocalDate getDataDevolucao() {
        return dataDevolucao;
    }

    //Modificar a data de devolucao
    public void setDataDevolucao(LocalDate dataDevolucao) {
        this.dataDevolucao = dataDevolucao;
    }

    //Retorno da situacao do emprestimo
    public boolean isDevolvido() {
        return devolvido;
    }

    //Modificar a situacao de emprestimo
    public void setDevolvido(boolean devolvido) {
        this.devolvido = devolvido;
    }
    
    //Metodo toString
    @Override
    public String toString() {
        return "Emprestimo{" + "id=" + id + ", idUsuario=" + idUsuario + ", idLivro=" + idLivro + ", dataEmprestimo=" + dataEmprestimo + ", dataDevolucao=" + dataDevolucao + ", devolvido=" + isDevolvido() + '}';
    }
}