package AtividadeAvaliativa;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class BibliotecaTest {
    public static void main(String[] args) {
        
        //Listas dinamicas para POO
        List<Usuario> usuarios = new ArrayList<>();
        List<Livro> livros = new ArrayList<>();
        List<Emprestimo> emprestimos = new ArrayList<>();
        
        //Adicionar usuario
        usuarios.add(new Usuario(831477, "Gabriel", "gabriel@email.com", "senha"));
        usuarios.add(new Usuario(042404, "Marcela", "marcela@email.com", "senha"));
        
        //Pesquisar dados de usuario por nome
        for (Usuario u : usuarios) {
            if (u.getNome().equals("Gabriel")){
                System.out.println(u);
            }
        }
        
        //Listar usuarios
        for (Usuario u : usuarios){
            System.out.println(u);
        }
        
        //Adicionar livro
        livros.add(new Livro(658, "Jogo de empresas na área de produção : programação e controle da produção", "Claus Leon Warschauer", "vol 17", "Revista de Administração de Empresas", "São Paulo", 1977));
        livros.add(new Livro(22, "A Escolha", "Kiera Cass", "1ª Ed", "Seguinte", "Carolina do Sul", 2014));
        
        //Exibir dados de um livro a partir do ID
        for (Livro l : livros) {
            if (l.getId() == 658){
                System.out.println(l);
            }
        }
        
        //Listar todos os livros
        for (Livro l : livros) {
            System.out.println(l);
        }
        
        //Realizar emprestimo
        emprestimos.add(new Emprestimo(1, 831477, 658, LocalDate.of(2020, 05, 04), LocalDate.of(2020, 05, 18), false));
        emprestimos.add(new Emprestimo(2, 042404, 22, LocalDate.of(2020, 02, 11), LocalDate.of(2020, 03, 24), false));
        
        //Listar todos os livros emprestados que ainda nao foram devolvidos
        for (Emprestimo e : emprestimos){
            if (e.isDevolvido() == false){
                    System.out.println(e);
            }
        }
        
        //Listar todos os livros que foram devolvidos
        for (Emprestimo e : emprestimos){
            if (e.getId() == 831477){
                e.setDevolvido(true);
            }
        }
        
        //Listar emprestimos
        for (Emprestimo e : emprestimos){
            if (e.isDevolvido() == true){
                    System.out.println(e);
            }
        }
    }
}