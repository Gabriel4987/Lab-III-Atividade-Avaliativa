package AtividadeAvaliativa;

public class Livro {
    
    //Atributos
    private int id;
    private String titulo;
    private String autor;
    private String edicao;
    private String editora;
    private String cidade;
    private int anoPublicacao;

    //Construtor padrão
    public Livro() {
    }

    //Construtor sobrecarregado
    public Livro(int id, String titulo, String autor, String edicao, String editora, String cidade, int anoPublicacao) {
        this.id = id;
        this.titulo = titulo;
        this.autor = autor;
        this.edicao = edicao;
        this.editora = editora;
        this.cidade = cidade;
        this.anoPublicacao = anoPublicacao;
    }

    //Retorno do id
    public int getId() {
        return id;
    }

    //Modificar o id
    public void setId(int id) {
        this.id = id;
    }

    //Retorno do titulo do livro
    public String getTitulo() {
        return titulo;
    }

    //Modificar o titulo do livro
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    //Retorno do autor do livro
    public String getAutor() {
        return autor;
    }

    //Modificar o autor do livro
    public void setAutor(String autor) {
        this.autor = autor;
    }

    //Retorno da edicao do livro
    public String getEdicao() {
        return edicao;
    }

    //Modificar a edicao do livro
    public void setEdicao(String edicao) {
        this.edicao = edicao;
    }

    //Retorno da editora do livro
    public String getEditora() {
        return editora;
    }

    //Modificar a editora do livro
    public void setEditora(String editora) {
        this.editora = editora;
    }

    //Retorno da cidade que foi publicado o livro
    public String getCidade() {
        return cidade;
    }

    //Modificar a cidade que foi publicado o livro
    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    //Retorno do ano de publicacao do livro
    public int getAnoPublicacao() {
        return anoPublicacao;
    }

    //Modificar o ano de publicacao do livro
    public void setAnoPublicacao(int anoPublicacao) {
        this.anoPublicacao = anoPublicacao;
    }

    //Metodo toString
    @Override
    public String toString() {
        return "Livro{" + "id=" + id + ", titulo=" + titulo + ", autor=" + autor + ", edicao=" + edicao + ", editora=" + editora + ", cidade=" + cidade + ", anoPublicacao=" + anoPublicacao + '}';
    }
}